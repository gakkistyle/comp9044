/* easymain.c */

#include "graphics.h"
#include "world.h"

int main(void) {return 0;}
