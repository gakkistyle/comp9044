/* b.h */

#include "bb.h"

void b(void);
