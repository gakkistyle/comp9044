/* a.h */

void a(void);
