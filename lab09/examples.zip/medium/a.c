/* a.c */

#include "a.h"
#include "common.h"
#include <stdio.h>

void a(void)
{
    printf("Hello, I'm a\n");
}
