/* aaa.c */

#include <stdio.h>

void aaa(void)
{
    printf("Hello, I'm aaa\n");
}
