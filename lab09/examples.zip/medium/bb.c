/* bb.c */

#include "bb.h"
#include <stdio.h>

void bb(void)
{
    printf("Hello, I'm bb\n");
    aaa();
}
