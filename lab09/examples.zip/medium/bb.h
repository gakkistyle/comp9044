/* bb.h */

#include "aaa.h"

void bb(void);
