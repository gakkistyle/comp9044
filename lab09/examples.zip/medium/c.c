/* c.c */

#include <ctype.h>

#include "c.h"
#include <stdio.h>
#include <stdlib.h>

void c(void)
{
    printf("Hello, I'm c\n");
}
