/* b.c */

#include "b.h"
#include <stdio.h>

void b(void)
{
    printf("Hello, I'm b\n");
    bb();
}
