/* c.h */

void c(void);
