/* circ2.c */

#include "circ2.h"

void circ2(void)
{
}
