/* circ1.h */

#include "circ2.h"

void circ1(void);
