/* circ1.c */

#include "circ1.h"

void circ1(void)
{
}
